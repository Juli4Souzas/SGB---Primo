<div class="row">
              <div class="col-md-12">
                <div class="card mb-0">
                  <div class="card-body">
                      <ul class="nav nav-pills" style="margin:5px; float:right;">
                      <li class="nav-item" >
                        <a class="nav-link active"  href="addProduto.php">Novo </a>
                      </li>
                     
                    </ul>
                    <ul class="nav nav-pills">
                    
                      <li class="nav-item">
                        <a class="nav-link active" href="<?=HOME?>/index.php" target="_blank">LOJA</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="index.php">Listar</a>
                      </li>
                     
                      
                     
                    </ul>
                  </div>
                </div>
              </div>
            </div>
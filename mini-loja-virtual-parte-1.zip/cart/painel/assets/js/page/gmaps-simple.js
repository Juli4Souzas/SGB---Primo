"use strict";

var simple_map = new GMaps({
  div: '#simple-map',
  lat: 23.014711,
  lng: 72.530810
})
